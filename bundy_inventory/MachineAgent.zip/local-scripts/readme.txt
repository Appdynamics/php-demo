This directory is a temporary store of runbook scripts provided by the controller for running if enabled.
