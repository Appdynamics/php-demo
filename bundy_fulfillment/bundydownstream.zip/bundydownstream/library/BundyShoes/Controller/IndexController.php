<?php

namespace BundyShoes\Controller;

class IndexController extends AbstractController {
    
    public function index($request)
    {
        return 'This is the index page';
    }
}