#!/bin/sh
php memcacheMonitor.php
