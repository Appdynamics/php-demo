<?php $view->extend('BundyShoesBundle::layout.html.php'); ?>

This is Checkout