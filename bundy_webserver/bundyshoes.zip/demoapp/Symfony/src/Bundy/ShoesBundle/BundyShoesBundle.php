<?php

namespace Bundy\ShoesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BundyShoesBundle extends Bundle
{
}
