<?php

namespace Bundy\ShoesBundle\DependencyInjection\Services;

/**
 * Exception Marker
 *
 * @category Bundy
 * @package Bundy\ShoeBundle
 * @subpackage Bundy\ShoeBundle\DependencyInjection\Services
 * @author rbolton
 */

interface Exception
{

}