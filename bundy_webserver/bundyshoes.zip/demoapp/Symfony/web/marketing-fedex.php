<?php

//sleep for 100 milliseconds...
usleep(100000);

echo 'Fedex response';
?>