<?php

$servers = array(
    array('host' => 'localhost', 'port' => '11211'),
);
?>